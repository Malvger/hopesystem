<br>
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Observaciones')); ?></td>
        </tr>
        <tr>
            <td>
                <textarea 
                    rows="8"
                    id="Observaciones"
                    type="text"
                    class="form-control"
                    name="Observaciones"><?php echo e(isset($estudiante->Observaciones)?$estudiante->Observaciones:''); ?></textarea>
            </td>
        </tr>
    </tbody>
</table>

<!--Gustavo's changing tabs code-->

<div class="row">
    <div class="col clearfix">
        <span class="float-left">
            <input type="button" class="btn btn-primary" value="<" onClick="selectTab('nav-dFamiliar');">
        </span>
    </div>
    <div class="col clearfix">
        <span class="float-right">
            <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
        </span>
    </div>
</div><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiantes/formo.blade.php ENDPATH**/ ?>