<br>

<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td colspan="8" ><?php echo e(__('El abastecimiento de aguas procede de:')); ?></td>
        </tr>
        <tr>
            <td>Agua potable </td>
            <td><input id="AguaP" type="checkbox" class="form-control" name="AguaP"
            <?php echo e(isset($estudioS->AguaP)?$estudioS->AguaP=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Rio</td>
            <td><input id="Rio" type="checkbox" class="form-control" name="Rio"
            <?php echo e(isset($estudioS->Rio)?$estudioS->Rio=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Pozo</td>
            <td><input id="Pozo" type="checkbox" class="form-control" name="Pozo"
            <?php echo e(isset($estudioS->Pozo)?$estudioS->Pozo=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Otro </td>
            <td><input id="Otro" type="checkbox" class="form-control" name="Otro"
            <?php echo e(isset($estudioS->Otro)?$estudioS->Otro=='1'?'checked':'':''); ?>

            value="1"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td colspan="8" ><?php echo e(__('¿Cuál es el tipo de alumbrado que tiene la vivienda?')); ?></td>
        </tr>
        <tr>
            <td>Electricidad </td>
            <td><input id="Electricidad" type="checkbox" class="form-control" name="Electricidad"
            <?php echo e(isset($estudioS->Electricidad)?$estudioS->Electricidad=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Velas </td>
            <td><input id="Velas" type="checkbox" class="form-control" name="Velas"
            <?php echo e(isset($estudioS->Velas)?$estudioS->Velas=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Otros</td>
            <td><input id="Otros03" type="checkbox" class="form-control" name="Otros03"
            <?php echo e(isset($estudioS->Otros03)?$estudioS->Otros03=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>No tiene  </td>
            <td><input id="NoT" type="checkbox" class="form-control" name="NoT"
            <?php echo e(isset($estudioS->NoT)?$estudioS->NoT=='1'?'checked':'':''); ?>

            value="1"></td>
        </tr>

        <tr class="bg-secondary text-white">
            <td colspan="8" ><?php echo e(__('El servicio sanitario que tiene la vivienda está conectado a:')); ?></td>
        </tr>
        <tr>
            <td>Drenaje  </td>
            <td><input id="Drenaje" type="checkbox" class="form-control" name="Drenaje"
            <?php echo e(isset($estudioS->Drenaje)?$estudioS->Drenaje=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Pozo séptico </td>
            <td><input id="PozoS" type="checkbox" class="form-control" name="PozoS"
            <?php echo e(isset($estudioS->PozoS)?$estudioS->PozoS=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Rio </td>
            <td><input id="Rio02" type="checkbox" class="form-control" name="Rio02"
            <?php echo e(isset($estudioS->Rio02)?$estudioS->Rio02=='1'?'checked':'':''); ?>

            value="1" ></td>
            <td>Otro  </td>
            <td><input id="Otro02" type="checkbox" class="form-control" name="Otro02"
            <?php echo e(isset($estudioS->Otro02)?$estudioS->Otro02=='1'?'checked':'':''); ?>

            value="1"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td colspan="8" ><?php echo e(__('Combustible mas utilizado para cocinar ')); ?></td>
        </tr>
        <tr>
            <td>Electricista   </td>
            <td><input id="Electricista02" type="checkbox" class="form-control" name="Electricista02"
            <?php echo e(isset($estudioS->Electricista02)?$estudioS->Electricista02=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Leña  </td>
            <td><input id="Lena" type="checkbox" class="form-control" name="Lena"
            <?php echo e(isset($estudioS->Lena)?$estudioS->Lena=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Gas </td>
            <td><input id="Gas" type="checkbox" class="form-control" name="Gas"
            <?php echo e(isset($estudioS->Gas)?$estudioS->Gas=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Otro  </td>
            <td><input id="Otro03" type="checkbox" class="form-control" name="Otro03"
            <?php echo e(isset($estudioS->Otro03)?$estudioS->Otro03=='1'?'checked':'':''); ?>

            value="1"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td colspan="8" ><?php echo e(__('¿Con que otro servicio cuenta?')); ?></td>
        </tr>
        <tr>
            <td>Teléfono fijo    </td>
            <td><input id="Telefono02" type="checkbox" class="form-control" name="Telefono02"
            <?php echo e(isset($estudioS->Telefono02)?$estudioS->Telefono02=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Cable   </td>
            <td><input id="Cable" type="checkbox" class="form-control" name="Cable"
            <?php echo e(isset($estudioS->Cable)?$estudioS->Cable=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Internet  </td>
            <td><input id="Internet" type="checkbox" class="form-control" name="Internet"
            <?php echo e(isset($estudioS->Internet)?$estudioS->Internet=='1'?'checked':'':''); ?>

            value="1"></td>
            <td>Celular   </td>
            <td><input id="Celular" type="checkbox" class="form-control" name="Celular"
            <?php echo e(isset($estudioS->Celular)?$estudioS->Celular=='1'?'checked':'':''); ?>

            value="1"></td>
        </tr>

    </tbody>
</table>

<!--Gustavo's changing tabs code-->

<div class="row">
    <div class="col clearfix">
        <span class="float-left">
            <input type="button" class="btn btn-primary" value="<" onClick="selectTab('nav-dFamiliar');">
        </span>
    </div>
    <div class="col clearfix">
        <span class="float-right">
            <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
        </span>
    </div>
</div><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiosocioeconimico/formsb.blade.php ENDPATH**/ ?>