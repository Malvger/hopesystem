
<br>
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Primer Nombre')); ?></td>
            <td><?php echo e(__('Segundo Nombre')); ?></td>
            <td><?php echo e(__('Apellido Paterno')); ?></td>
            <td><?php echo e(__('Apellido Paterno')); ?></td>
        </tr>
        <tr>
            <td><input id="PrimerNombre" type="text" class="form-control" name="PrimerNombre" 
                value="<?php echo e(isset($estudiante->PrimerNombre)?$estudiante->PrimerNombre:''); ?>"></td>
            <td><input id="SegundoNombre" type="text" class="form-control" name="SegundoNombre" 
                value="<?php echo e(isset($estudiante->SegundoNombre)?$estudiante->SegundoNombre:''); ?>"></td>
            <td><input id="ApellidoPaterno" type="text" class="form-control" name="ApellidoPaterno" 
                value="<?php echo e(isset($estudiante->ApellidoPaterno)?$estudiante->ApellidoPaterno:''); ?>"></td>
            <td><input id="ApellidoMaterno" type="text" class="form-control" name="ApellidoMaterno" 
                value="<?php echo e(isset($estudiante->ApellidoMaterno)?$estudiante->ApellidoMaterno:''); ?>"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Sexo')); ?></td>
            <td><?php echo e(__('Edad')); ?></td>
            <td><?php echo e(__('CUI')); ?></td>
            <td><?php echo e(__('Comunidad Étnica')); ?></td>
        </tr>
        <tr>
            <td><input id="Sexo" type="text" class="form-control" name="Sexo" 
                value="<?php echo e(isset($estudiante->Sexo)?$estudiante->Sexo:''); ?>"></td>
            <td><input id="Edad" type="text" class="form-control" name="Edad" 
                value="<?php echo e(isset($estudiante->Edad)?$estudiante->Edad:''); ?>"></td>
            <td><input id="CUI" type="text" class="form-control" name="CUI" 
                value="<?php echo e(isset($estudiante->CUI)?$estudiante->CUI:''); ?>"></td>
            <td><input id="ComunidadEtnica" type="text" class="form-control" name="ComunidadEtnica" 
                value="<?php echo e(isset($estudiante->ComunidadEtnica)?$estudiante->ComunidadEtnica:''); ?>"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Lugar de Nacimiento')); ?></td>
            <td><?php echo e(__('Fecha de Nacimiento')); ?></td>
            <td><?php echo e(__('Idioma Materno')); ?></td>
            <td><?php echo e(__('Segundo Idioma')); ?></td>
        </tr>
        <tr>
            <td><input id="LugarNacimiento" type="text" class="form-control" name="LugarNacimiento" 
                value="<?php echo e(isset($estudiante->LugarNacimiento)?$estudiante->LugarNacimiento:''); ?>"></td>
            <td><input id="FechaNacimiento" type="date" class="form-control" name="FechaNacimiento"
                value="<?php echo e(isset($estudiante->FechaNacimiento)?$estudiante->FechaNacimiento:''); ?>"></td>
            <td><input id="IdiomaMaterno" type="text" class="form-control" name="IdiomaMaterno" 
                value="<?php echo e(isset($estudiante->IdiomaMaterno)?$estudiante->IdiomaMaterno:''); ?>"></td>
            <td><input id="SugundoIdioma" type="text" class="form-control" name="SugundoIdioma" 
                value="<?php echo e(isset($estudiante->SugundoIdioma)?$estudiante->SugundoIdioma:''); ?>"></td>
        </tr>
    </tbody>
</table>

<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Nombre y Apellidos de la Madre')); ?></td>
            <td><?php echo e(__('Nombre y Apellidos del Padre')); ?></td>
        </tr>
        <tr>
            <td><input id="NombreApellidoMadre" type="text" class="form-control" name="NombreApellidoMadre" 
                value="<?php echo e(isset($estudiante->NombreApellidoMadre)?$estudiante->NombreApellidoMadre:''); ?>"></td>
            <td><input id="NombreApellidoPadre" type="text" class="form-control" name="NombreApellidoPadre" 
                value="<?php echo e(isset($estudiante->NombreApellidoPadre)?$estudiante->NombreApellidoPadre:''); ?>"></td>
        </tr>
    </tbody>
</table>
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('DPI de la Madre')); ?></td>
            <td><?php echo e(__('No. Tel de la Madre')); ?></td>
            <td><?php echo e(__('DPI del Padre')); ?></td>
            <td><?php echo e(__('No. Tel. del Padre')); ?></td>
        </tr>
        <tr>
            <td><input id="DPIMadre" type="text" class="form-control" name="DPIMadre" 
                value="<?php echo e(isset($estudiante->DPIMadre)?$estudiante->DPIMadre:''); ?>"></td>
            <td><input id="TelMadre" type="text" class="form-control" name="TelMadre" 
                value="<?php echo e(isset($estudiante->TelMadre)?$estudiante->TelMadre:''); ?>"></td>
            <td><input id="DPIPadre" type="text" class="form-control" name="DPIPadre" 
                value="<?php echo e(isset($estudiante->DPIPadre)?$estudiante->DPIPadre:''); ?>"></td>
            <td><input id="TelPadre" type="text" class="form-control" name="TelPadre" 
                value="<?php echo e(isset($estudiante->TelPadre)?$estudiante->TelPadre:''); ?>"></td>
        </tr>
    </tbody>
</table>

<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Nombres y Apellidos del Encargado')); ?></td>
            <td><?php echo e(__('DPI del Encargado')); ?></td>
            <td><?php echo e(__('No. Tel. del Encargado')); ?></td>
        </tr>
        <tr>
            <td><input id="NombreApellidoEncargado" type="text" class="form-control" name="NombreApellidoEncargado" 
                value="<?php echo e(isset($estudiante->NombreApellidoEncargado)?$estudiante->NombreApellidoEncargado:''); ?>"></td>
            <td><input id="DPIMadreEncargado" type="text" class="form-control" name="DPIMadreEncargado" 
                value="<?php echo e(isset($estudiante->DPIMadreEncargado)?$estudiante->DPIMadreEncargado:''); ?>"></td>
            <td><input id="TelMadreEncargado" type="text" class="form-control" name="TelMadreEncargado" 
                value="<?php echo e(isset($estudiante->TelMadreEncargado)?$estudiante->TelMadreEncargado:''); ?>"></td>
        </tr>
    </tbody>
</table>
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Dirección Domiciliar del Estudiante')); ?></td>
        </tr>
        <tr>
            <td><input id="DireccionDomicilioEstudiante" type="text" class="form-control" name="DireccionDomicilioEstudiante"
                value="<?php echo e(isset($estudiante->DireccionDomicilioEstudiante)?$estudiante->DireccionDomicilioEstudiante:''); ?>"></td>
        </tr>
    </tbody>
</table>
<br>
<h5>DATOS ACADÉMICOS</h5>

<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Establecimiento del que Proviene')); ?></td>
        </tr>
        <tr>
            <td><input id="EstablecimientoProviene" type="text" class="form-control" name="EstablecimientoProviene" 
                value="<?php echo e(isset($estudiante->EstablecimientoProviene)?$estudiante->EstablecimientoProviene:''); ?>"></td>
        </tr>
    </tbody>
</table>
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Grado a Ingresar')); ?></td>
            <td><?php echo e(__('Repitente')); ?></td>
            <td><?php echo e(__('No. de Veces')); ?></td>
        </tr>
        <tr>
            <td><input id="GradoIngresar" type="text" class="form-control" name="GradoIngresar" 
                value="<?php echo e(isset($estudiante->GradoIngresar)?$estudiante->GradoIngresar:''); ?>"></td>
            <td>
                <input id="RepitenteSi" type="checkbox" class="form-control" name="RepitenteSi" 

                    <?php echo e(isset($estudiante->RepitenteNo)?$estudiante->RepitenteSi=='1'?'checked':'':''); ?>

                    
                    value="1"
                    >
                
                
                    
                    

            </td>
            <td>
                
                <select id="Noveces" class="form-control" name="Noveces">  
                    <option value="0" <?php echo e(isset($estudiante->Noveces)?$estudiante->Noveces=='0'?'selected':'':''); ?> > 0 </option>  
                    <option value="1" <?php echo e(isset($estudiante->Noveces)?$estudiante->Noveces=='1'?'selected':'':''); ?>> 1 </option>  
                    <option value="2" <?php echo e(isset($estudiante->Noveces)?$estudiante->Noveces=='2'?'selected':'':''); ?>> 2 </option>  
                    <option value="3" <?php echo e(isset($estudiante->Noveces)?$estudiante->Noveces=='3'?'selected':'':''); ?>> 3 </option>  
                    <option value="4" <?php echo e(isset($estudiante->Noveces)?$estudiante->Noveces=='4'?'selected':'':''); ?>> 4 </option>  
                    <option value="5" <?php echo e(isset($estudiante->Noveces)?$estudiante->Noveces=='5'?'selected':'':''); ?>> 5 </option>  
                </select>
            </td>
        </tr>
    </tbody>
</table>

<!--Gustavo's changing tabs code-->

<div class="row">
    <div class="col clearfix">
        <span class="float-left">
            <input type="button" disabled="true" class="btn btn-primary" value="<" onClick="selectTab('nav-sFisica');">
        </span>
    </div>
    <div class="col clearfix">
        <span class="float-right">
            <input type="button" class="btn btn-primary" value=">" onClick="selectTab('nav-sFisica');">
        </span>
    </div>
</div><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiantes/formde.blade.php ENDPATH**/ ?>