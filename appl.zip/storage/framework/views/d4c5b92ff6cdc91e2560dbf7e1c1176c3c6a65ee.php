<br>

<!-- <h5>I.	DATOS DE RESPONSABLE DE LA FAMILIA </h5> -->
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td colspan="2"> <?php echo e(__('Apellidos')); ?></td>
            <td colspan="2"><?php echo e(__('Nombres')); ?></td>
        </tr>
        <tr>
            <td colspan="2"><input id="Apellidos" type="text" class="form-control" name="Apellidos" 
                value="<?php echo e(isset($estudioS->Apellidos)?$estudioS->Apellidos:''); ?>"></td>
            <td colspan="2"><input id="Nombres" type="text" class="form-control" name="Nombres" 
                value="<?php echo e(isset($estudioS->Nombres)?$estudioS->Nombres:''); ?>"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Sexo')); ?></td>
            <td><?php echo e(__('Edad')); ?></td>
            <td><?php echo e(__('CUI')); ?></td>
            <td><?php echo e(__('Comunidad Étnica')); ?></td>
        </tr>
        <tr>
            <td><input id="Sexo" type="text" class="form-control" name="Sexo" 
                value="<?php echo e(isset($estudioS->Sexo)?$estudioS->Sexo:''); ?>"></td>
            <td><input id="Edad" type="text" class="form-control" name="Edad" 
                value="<?php echo e(isset($estudioS->Edad)?$estudioS->Edad:''); ?>"></td>
            <td><input id="CUI" type="text" class="form-control" name="CUI" 
                value="<?php echo e(isset($estudioS->CUI)?$estudioS->CUI:''); ?>"></td>
            <td><input id="ComunidadEtnica" type="text" class="form-control" name="ComunidadEtnica" 
                value="<?php echo e(isset($estudioS->ComunidadEtnica)?$estudioS->ComunidadEtnica:''); ?>"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Estado Civil')); ?></td>
            <td><?php echo e(__('Idioma Materno')); ?></td>
            <td><?php echo e(__('Segundo Idioma')); ?></td>
            <td><?php echo e(__('No. Telefono')); ?></td>
        </tr>
        <tr>
            <td><input id="EstadoS" type="text" class="form-control" name="EstadoS" 
                value="<?php echo e(isset($estudioS->EstadoS)?$estudioS->EstadoS:''); ?>"></td>
            <td><input id="IdiomaMaterno" type="text" class="form-control" name="IdiomaMaterno"
                value="<?php echo e(isset($estudioS->IdiomaMaterno)?$estudioS->IdiomaMaterno:''); ?>"></td>
            <td><input id="SugundoIdioma" type="text" class="form-control" name="SugundoIdioma" 
                value="<?php echo e(isset($estudioS->SugundoIdioma)?$estudioS->SugundoIdioma:''); ?>"></td>
            <td><input id="NoTelefono" type="text" class="form-control" name="NoTelefono" 
                value="<?php echo e(isset($estudioS->NoTelefono)?$estudioS->NoTelefono:''); ?>"></td>
        </tr>
        </tr>
        <tr class="bg-secondary text-white">
            <td><?php echo e(__('Profesión u oficio ')); ?></td>
            <td><?php echo e(__('Tipo de empleo ')); ?></td>
            <td><?php echo e(__('Ingresos mensuales ')); ?></td>
            <td><?php echo e(__('Egresos mensuales')); ?></td>
        </tr>
        <tr>
            <td><input id="Proficion" type="text" class="form-control" name="Proficion" 
                value="<?php echo e(isset($estudioS->Proficion)?$estudioS->Proficion:''); ?>"></td>
            <td><input id="Empleo" type="text" class="form-control" name="Empleo"
                value="<?php echo e(isset($estudioS->Empleo)?$estudioS->Empleo:''); ?>"></td>
            <td><input id="IngresoM" type="text" class="form-control" name="IngresoM" 
                value="<?php echo e(isset($estudioS->IngresoM)?$estudioS->IngresoM:''); ?>"></td>
            <td><input id="Egresos" type="text" class="form-control" name="Egresos" 
                value="<?php echo e(isset($estudioS->Egresos)?$estudioS->Egresos:''); ?>"></td>
        </tr>
        <tr class="bg-secondary text-white">
            <td colspan="4"><?php echo e(__('Dirección domiciliar  ')); ?></td>
        </tr>
        <tr>
            <td colspan="4"> <input id="DireccionD" type="text" class="form-control" name="DireccionD" 
                value="<?php echo e(isset($estudioS->DireccionD)?$estudioS->DireccionD:''); ?>"></td>
        </tr>
    </tbody>
</table>






<div class="row">
    <div class="col clearfix">
        <span class="float-left">
            <input type="button" disabled="true" class="btn btn-primary" value="<" onClick="selectTab('nav-sFisica');">
        </span>
    </div>
    <div class="col clearfix">
        <span class="float-right">
            <input type="button" class="btn btn-primary" value=">" onClick="selectTab('nav-sFisica');">
        </span>
    </div>
</div><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiosocioeconimico/formdrf.blade.php ENDPATH**/ ?>