<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header"><?php echo e(__('Datos del Estudiente Nivel Preprimaria y Primero')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/estudiantes')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo $__env->make('estudiantes.form', ['Modo'=>'crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiantes/create.blade.php ENDPATH**/ ?>