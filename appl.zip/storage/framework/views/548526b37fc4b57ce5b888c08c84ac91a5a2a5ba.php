<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header"><?php echo e(__('Datos del Estudiente Nivel Medio, Ciclo Diversificado')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/estudiosocioeconimico')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo $__env->make('estudiosocioeconimico.form', ['Modo'=>'crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiosocioeconimico/create.blade.php ENDPATH**/ ?>