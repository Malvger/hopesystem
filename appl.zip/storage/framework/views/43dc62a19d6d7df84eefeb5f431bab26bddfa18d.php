<br>
<table class="table table-bordered" width="100%" cellspacing="0">
    <tbody>
        <tr class="bg-secondary text-white">
            <td ><?php echo e(__('¿Algún miembro que conforma su hogar presenta problema de salud? ')); ?></td>
            <td>
                    <input id="problemasSalud" type="checkbox" class="form-control" name="problemasSalud"
                    <?php echo e(isset($estudioS->problemasSalud)?$estudioS->problemasSalud=='1'?      'checked':'':''); ?>

                    value="1">
              </td>
        </tr>
        <tr>
          <td colspan="2">
            <input id="Especifique" type="text" class="form-control" name="Especifique" placeholder="Especifique"
            value="<?php echo e(isset($estudioS->Especifique)?$estudioS->Especifique:''); ?>"> 
          </td>
        </tr>
        <tr>
          <td colspan="2">
              <input id="NombreApellido" type="text" class="form-control" name="NombreApellido" placeholder="Si la respuesta fue si ¿Quién? (Nombre y Apellido)"
                value="<?php echo e(isset($estudioS->NombreApellido)?$estudioS->NombreApellido:''); ?>"> 
                </td>
        </tr>

        <tr class="bg-secondary text-white">
            <td ><?php echo e(__('¿Existe en la familia algún miembro con discapacidad?')); ?></td>
            <td>
                    <input id="DiscapacidadSi" type="checkbox" class="form-control" name="DiscapacidadSi"
                    <?php echo e(isset($estudioS->DiscapacidadSi)?$estudioS->DiscapacidadSi=='1'?      'checked':'':''); ?>

                    value="1">
              </td>
        </tr>
        <tr>
          <td colspan="2">
            <input id="Especifice01" type="text" class="form-control" name="Especifice01" placeholder="Especifique"
            value="<?php echo e(isset($estudioS->Especifice01)?$estudioS->Especifice01:''); ?>"> 
          </td>
        </tr>
        <tr>
          <td colspan="2">
              <input id="NombreApellido02" type="text" class="form-control" name="NombreApellido02" placeholder="Si la respuesta fue si ¿Quién? (Nombre y Apellido)"
                value="<?php echo e(isset($estudioS->NombreApellido02)?$estudioS->NombreApellido02:''); ?>"> 
                </td>
        </tr>

        <tr class="bg-secondary text-white">
            <td ><?php echo e(__('¿Hay en el hogar personas mayores de edad?')); ?></td>
            <td>
                    <input id="Mayor" type="checkbox" class="form-control" name="Mayor"
                    <?php echo e(isset($estudioS->Mayor)?$estudioS->Mayor=='1'?      'checked':'':''); ?>

                    value="1">
              </td>
        </tr>
        <tr>
          <td colspan="2">
            <input id="Espesifique02" type="text" class="form-control" name="Espesifique02" placeholder="Especifique"
            value="<?php echo e(isset($estudioS->Espesifique02)?$estudioS->Espesifique02:''); ?>"> 
          </td>
        </tr>


    </tbody>
</table>
    

<br>

<div class="row">
    <div class="col clearfix">
        <span class="float-left">
            <input type="button" class="btn btn-primary" value="<" onClick="selectTab('nav-estudiantes');">
        </span>
    </div>
    <div class="col clearfix">
        <span class="float-right">
            <input type="button" class="btn btn-primary" value=">" onClick="selectTab('nav-dFamiliar');">
        </span>
    </div>
</div><?php /**PATH F:\proyect\2020\hopesystem\resources\views/estudiosocioeconimico/formsfp.blade.php ENDPATH**/ ?>