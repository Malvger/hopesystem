<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estudiantes1 extends Model
{
    //
}
