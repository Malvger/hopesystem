# hopesystem

Iniciar Repositorio 

git init

Agregar archivos al repositorio 

git add .

Crear un commit 

git commit -m "first commit"

Agregar remote 

git remote add origin https://github.com/Malvger/hopesystem.git

para actualizar datos

git pull

para subir 

git push -u origin master

otro comandos 

git fetch
git rebase origin/master
git push

# Laravel


php artisan serve

crear modelo um modelo
crea modelo, controloador y recursos

php artisan make:model modeloX -mcr

php artisan migrate

